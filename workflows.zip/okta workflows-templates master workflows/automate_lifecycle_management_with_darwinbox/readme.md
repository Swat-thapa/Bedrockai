# Automate lifecycle management with Darwinbox

This template is built and provided by Darwinbox. For instructions on using this template with Darwinbox, see [Darwinbox](https://marketplace.darwinbox.com/en-US/apps/435602/okta/resources).